# Memory Game Project

This is the course project of Udacity front-end development nenodegree.

## Download and start
You can clone or download the project. Then, open the `index.html`, and click the card and the game will start!!!.

## How to play
It's the traditional card memory game. Click cards and find the matching pair. After you find all 8 pairs, the game will finish. And also, you can click the refresh button to refresh the game (it will shuffle the cards).

## Dependencies
Front style from 'https://fonts.googleapis.com/css?family=Coda'; Run on HTML5, CSS3 and JavaScript ES6; no other dependencies.