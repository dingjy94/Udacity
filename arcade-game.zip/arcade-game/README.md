frontend-nanodegree-arcade-game
===============================

## Run
Just open the `index.html`, and the game will start.

## How to play
Move the boy with your keyborad's up, down, left and right. Be carful not to touch the enemy. If you pass to the water side, you will win!
